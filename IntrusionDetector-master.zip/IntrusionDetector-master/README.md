Deep neural network models for malicious packet detection. 
In this work we introduce a network intrusion detection approach (NIDS) for network conncetion records, which is based on deep learning methods for natural language processing (NLP).

For training and testing we use the KDD99 and KDD-NSL datasets.
