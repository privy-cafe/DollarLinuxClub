# Wireguard-DNScrypt-VPN-Server
## In under 3 minutes* with just a few klicks
### Setup Wireguard VPN Server,
#### incl. ipv4 and ipv6
#### incl. DNScrypt / DNSSEC (unbound)
#### incl. Ad-, Maleware-, ..., Blocking
#### incl. 3 ready client config files  ( one with QR-Code in terminal )


----------------------------------------
How to install :
###### For Debian and Ubuntu 18.04 :
```
wget -O  wireguard_dnscrypt_setup.sh https://raw.githubusercontent.com/zzzkeil/Wireguard-DNScrypt-VPN-Server/master/debian_ubuntu/wireguard_from_source_setup.sh

chmod +x wireguard_dnscrypt_setup.sh

./wireguard_dnscrypt_setup.sh
```
-----------------------------------------

@ the end you see the QR Code for your wiregaurd app.
example:
[![example](https://zeroaim.de/01/qrtest.png)](https://github.com/zzzkeil/Wireguard-DNScrypt-VPN-Server)

-----------------------------------------







( *less then 2 minutes on my v-server ) 
