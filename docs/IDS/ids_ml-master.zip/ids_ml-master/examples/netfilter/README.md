- To compile LKM/Netfilter example:

      $ make

- To load LKM/Netfilter example:

      $ sudo insmod simplePacketFilter.ko

- To list filter messages (status):

      $ dmesg

- To unload LKM/Netfilter example:

      $ sudo rmmod simplePacketFilter

