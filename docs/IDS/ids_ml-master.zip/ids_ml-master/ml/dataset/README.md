# TRAbID Dataset

Source:
------
<https://secplab.ppgia.pucpr.br/?q=trabid>

Publication:
------
Viegas, Eduardo K., Altair O. Santin, and Luiz S. Oliveira. "Toward a reliable anomaly-based intrusion detection in real-world environments." Computer Networks 127 (2017): 200-216.