# Rule Based - eBPF/XDP and netfilter examples

### Blocking Nmap Probing Scan

Based on TCP flags and Window Size

- TCP SYN
- TCP FIN
- TCP NULL
- TCP XMAS