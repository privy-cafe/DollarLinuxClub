#!/bin/sh

make clean || true
rm -fr .libs Makefile *_out valgrind.log
