<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Latvian_Firefox
</name>

<description>
   <am>Latvian localisation of Firefox</am>
   <ar>Latvian localisation of Firefox</ar>
   <bg>Latvian localisation of Firefox</bg>
   <ca>Localització de Firefox en Latvi</ca>
   <cs>Latvian localisation of Firefox</cs>
   <da>Lettisk oversættelse af Firefox</da>
   <de>Lettische Lokalisierung von Firefox</de>
   <el>Λετονική εντοπισμός του Firefox</el>
   <en>Latvian localisation of Firefox</en>
   <es>Latvian localisation of Firefox</es>
   <et>Latvian localisation of Firefox</et>
   <eu>Latvian localisation of Firefox</eu>
   <fa>Latvian localisation of Firefox</fa>
   <fi>Latvian localisation of Firefox</fi>
   <fr>Localisation lettone pour Firefox</fr>
   <he_IL>Latvian localisation of Firefox</he_IL>
   <hi>Latvian localisation of Firefox</hi>
   <hr>Latvian localisation of Firefox</hr>
   <hu>Latvian localisation of Firefox</hu>
   <id>Latvian localisation of Firefox</id>
   <is>Latvian localisation of Firefox</is>
   <it>Localizzazione lettone di Firefox</it>
   <ja_JP>Latvian localisation of Firefox</ja_JP>
   <ja>Latvian localisation of Firefox</ja>
   <kk>Latvian localisation of Firefox</kk>
   <ko>Latvian localisation of Firefox</ko>
   <lt>Latvian localisation of Firefox</lt>
   <mk>Latvian localisation of Firefox</mk>
   <nb>Latvian localisation of Firefox</nb>
   <nl>Letse lokalisatie van Firefox</nl>
   <pl>Łotewska lokalizacja przeglądarki Firefox</pl>
   <pt_BR>Letão Localização para Firefox</pt_BR>
   <pt>Letão Localização para Firefox</pt>
   <ro>Latvian localisation of Firefox</ro>
   <ru>Latvian localisation of Firefox</ru>
   <sk>Latvian localisation of Firefox</sk>
   <sl>Latvian localisation of Firefox</sl>
   <sq>Latvian localisation of Firefox</sq>
   <sr>Latvian localisation of Firefox</sr>
   <sv>Lettländsk lokalisering av Firefox</sv>
   <tr>Latvian localisation of Firefox</tr>
   <uk>Latvian локалізація of Firefox</uk>
   <zh_CN>Latvian localisation of Firefox</zh_CN>
   <zh_TW>Latvian localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-lv
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-lv
</uninstall_package_names>
</app>
