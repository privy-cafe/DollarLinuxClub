<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Turkish_Firefox
</name>

<description>
   <am>Turkish localisation of Firefox</am>
   <ar>Turkish localisation of Firefox</ar>
   <bg>Turkish localisation of Firefox</bg>
   <ca>Localització de Firefox en Turc</ca>
   <cs>Turkish localisation of Firefox</cs>
   <da>Tyrkisk oversættelse af Firefox</da>
   <de>Türkische Lokalisierung von Firefox</de>
   <el>Τουρκικός εντοπισμός του Firefox</el>
   <en>Turkish localisation of Firefox</en>
   <es>Turkish localisation of Firefox</es>
   <et>Turkish localisation of Firefox</et>
   <eu>Turkish localisation of Firefox</eu>
   <fa>Turkish localisation of Firefox</fa>
   <fi>Turkish localisation of Firefox</fi>
   <fr>Localisation turque pour Firefox</fr>
   <he_IL>Turkish localisation of Firefox</he_IL>
   <hi>Turkish localisation of Firefox</hi>
   <hr>Turkish localisation of Firefox</hr>
   <hu>Turkish localisation of Firefox</hu>
   <id>Turkish localisation of Firefox</id>
   <is>Turkish localisation of Firefox</is>
   <it>Localizzazione turca di Firefox</it>
   <ja_JP>Turkish localisation of Firefox</ja_JP>
   <ja>Turkish localisation of Firefox</ja>
   <kk>Turkish localisation of Firefox</kk>
   <ko>Turkish localisation of Firefox</ko>
   <lt>Turkish localisation of Firefox</lt>
   <mk>Turkish localisation of Firefox</mk>
   <nb>Turkish localisation of Firefox</nb>
   <nl>Turkse lokalisatie van Firefox</nl>
   <pl>Turecka lokalizacja przeglądarki Firefox</pl>
   <pt_BR>Turco Localização para Firefox</pt_BR>
   <pt>Turco Localização para Firefox</pt>
   <ro>Turkish localisation of Firefox</ro>
   <ru>Turkish localisation of Firefox</ru>
   <sk>Turkish localisation of Firefox</sk>
   <sl>Turkish localisation of Firefox</sl>
   <sq>Turkish localisation of Firefox</sq>
   <sr>Turkish localisation of Firefox</sr>
   <sv>Turkisk lokalisering av Firefox</sv>
   <tr>Turkish localisation of Firefox</tr>
   <uk>Turkish localisation of Firefox</uk>
   <zh_CN>Turkish localisation of Firefox</zh_CN>
   <zh_TW>Turkish localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-tr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-tr
</uninstall_package_names>
</app>
