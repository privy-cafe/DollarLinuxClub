<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Basque_Firefox
</name>

<description>
   <am>Basque localisation of Firefox</am>
   <ar>Basque localisation of Firefox</ar>
   <bg>Basque localisation of Firefox</bg>
   <ca>Localització de Firefox en Euskara</ca>
   <cs>Basque localisation of Firefox</cs>
   <da>Baskisk oversættelse af Firefox</da>
   <de>Baskische Lokalisierung von Firefox</de>
   <el>Basque εντοπισμός του Firefox</el>
   <en>Basque localisation of Firefox</en>
   <es>Localización Vasco de Firefox</es>
   <et>Basque localisation of Firefox</et>
   <eu>Basque localisation of Firefox</eu>
   <fa>Basque localisation of Firefox</fa>
   <fi>Basque localisation of Firefox</fi>
   <fr>Localisation basque pour Firefox</fr>
   <he_IL>Basque localisation of Firefox</he_IL>
   <hi>Basque localisation of Firefox</hi>
   <hr>Baskijska lokalizacija Firefoxa</hr>
   <hu>Basque localisation of Firefox</hu>
   <id>Basque localisation of Firefox</id>
   <is>Basque localisation of Firefox</is>
   <it>Localizzazione basca di Firefox</it>
   <ja_JP>Basque localisation of Firefox</ja_JP>
   <ja>Basque localisation of Firefox</ja>
   <kk>Basque localisation of Firefox</kk>
   <ko>Basque localisation of Firefox</ko>
   <lt>Basque localisation of Firefox</lt>
   <mk>Basque localisation of Firefox</mk>
   <nb>Basque localisation of Firefox</nb>
   <nl>Baskische lokalisatie van Firefox</nl>
   <pl>Baskijska lokalizacja przeglądarki Firefox</pl>
   <pt_BR>Basco Localização para Firefox</pt_BR>
   <pt>Basco Localização para Firefox</pt>
   <ro>Basque localisation of Firefox</ro>
   <ru>Basque localisation of Firefox</ru>
   <sk>Basque localisation of Firefox</sk>
   <sl>Basque localisation of Firefox</sl>
   <sq>Basque localisation of Firefox</sq>
   <sr>Basque localisation of Firefox</sr>
   <sv>Baskisk lokalisering av Firefox</sv>
   <tr>Basque localisation of Firefox</tr>
   <uk>Basque локалізація Firefox</uk>
   <zh_CN>Basque localisation of Firefox</zh_CN>
   <zh_TW>Basque localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-eu
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-eu
</uninstall_package_names>
</app>
