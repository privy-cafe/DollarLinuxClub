<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Czech
</name>

<description>
   <am>Czech Language Meta-Package</am>
   <ar>Czech Language Meta-Package</ar>
   <bg>Czech Language Meta-Package</bg>
   <ca>Meta-paquet per llengua Txeca</ca>
   <cs>Czech Language Meta-Package</cs>
   <da>Tjekkisk sprog-metapakke</da>
   <de>Tschechisches Sprach-Meta-Paket</de>
   <el>Τσεχική γλώσσα</el>
   <en>Czech Language Meta-Package</en>
   <es>Czech Language Meta-Package</es>
   <et>Czech Language Meta-Package</et>
   <eu>Czech Language Meta-Package</eu>
   <fa>Czech Language Meta-Package</fa>
   <fi>Czech Language Meta-Package</fi>
   <fr>Méta-Paquet langue tchèque</fr>
   <he_IL>Czech Language Meta-Package</he_IL>
   <hi>Czech Language Meta-Package</hi>
   <hr>Czech Language Meta-Package</hr>
   <hu>Czech Language Meta-Package</hu>
   <id>Czech Language Meta-Package</id>
   <is>Czech Language Meta-Package</is>
   <it>Meta-pacchetto della lingua ceca</it>
   <ja_JP>Czech Language Meta-Package</ja_JP>
   <ja>Czech Language Meta-Package</ja>
   <kk>Czech Language Meta-Package</kk>
   <ko>Czech Language Meta-Package</ko>
   <lt>Czech Language Meta-Package</lt>
   <mk>Czech Language Meta-Package</mk>
   <nb>Czech Language Meta-Package</nb>
   <nl>Tjechische Taal Meta-Pakket</nl>
   <pl>Czeski metapakiet językowy</pl>
   <pt_BR>Checo Meta-Pacote de Idioma</pt_BR>
   <pt>Checo Meta-Pacote de Idioma</pt>
   <ro>Czech Language Meta-Package</ro>
   <ru>Czech Language Meta-Package</ru>
   <sk>Czech Language Meta-Package</sk>
   <sl>Czech Language Meta-Package</sl>
   <sq>Czech Language Meta-Package</sq>
   <sr>Czech Language Meta-Package</sr>
   <sv>Tjeckiskt Språk Meta-Paket</sv>
   <tr>Czech Language Meta-Package</tr>
   <uk>Czech Language Meta-Package</uk>
   <zh_CN>Czech Language Meta-Package</zh_CN>
   <zh_TW>Czech Language Meta-Package</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
aspell-cs
myspell-cs
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
aspell-cs
myspell-cs
</uninstall_package_names>
</app>
