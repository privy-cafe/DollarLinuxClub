<?xml version="1.0"?>
<app>

<category>
Docks
</category>

<name>
Docky
</name>

<description>
   <am>Elegant, Clean, Powerful Dock</am>
   <ar>Elegant, Clean, Powerful Dock</ar>
   <bg>Elegant, Clean, Powerful Dock</bg>
   <ca>Acoblador elegant, net i potent</ca>
   <cs>Elegant, Clean, Powerful Dock</cs>
   <da>Elegant, ren og kraftfuld dok</da>
   <de>Elegantes, sauberes, leistungsstarkes Dock</de>
   <el>Κομψό, καθαρό, ισχυρό Dock</el>
   <en>Elegant, Clean, Powerful Dock</en>
   <es>un dock elegante, simple y potente</es>
   <et>Elegant, Clean, Powerful Dock</et>
   <eu>Elegant, Clean, Powerful Dock</eu>
   <fa>Elegant, Clean, Powerful Dock</fa>
   <fi>Elegant, Clean, Powerful Dock</fi>
   <fr>Un Dock puissant, clair, et esthétique</fr>
   <he_IL>Elegant, Clean, Powerful Dock</he_IL>
   <hi>Elegant, Clean, Powerful Dock</hi>
   <hr>Elegant, Clean, Powerful Dock</hr>
   <hu>Elegant, Clean, Powerful Dock</hu>
   <id>Elegant, Clean, Powerful Dock</id>
   <is>Elegant, Clean, Powerful Dock</is>
   <it>Barra dock elegante, pulita, potente</it>
   <ja_JP>Elegant, Clean, Powerful Dock</ja_JP>
   <ja>Elegant, Clean, Powerful Dock</ja>
   <kk>Elegant, Clean, Powerful Dock</kk>
   <ko>Elegant, Clean, Powerful Dock</ko>
   <lt>Elegant, Clean, Powerful Dock</lt>
   <mk>Elegant, Clean, Powerful Dock</mk>
   <nb>Elegant, Clean, Powerful Dock</nb>
   <nl>Elegant, Schoon, Krachtig Dock</nl>
   <pl>elegancki, czysty, potężny panel dokujący</pl>
   <pt_BR>Elegant, Clean, Powerful Dock</pt_BR>
   <pt>Doca elegante, sóbria e poderosa</pt>
   <ro>Elegant, Clean, Powerful Dock</ro>
   <ru>Элегантный, чистый и мощный док</ru>
   <sk>Elegant, Clean, Powerful Dock</sk>
   <sl>Elegant, Clean, Powerful Dock</sl>
   <sq>Elegant, Clean, Powerful Dock</sq>
   <sr>Elegant, Clean, Powerful Dock</sr>
   <sv>Elegant, Ren, Kraftfull Docka</sv>
   <tr>Elegant, Clean, Powerful Dock</tr>
   <uk>Потужний і гарний док</uk>
   <zh_CN>Elegant, Clean, Powerful Dock</zh_CN>
   <zh_TW>Elegant, Clean, Powerful Dock</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/004/689/thumb.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
docky
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
docky
</uninstall_package_names>
</app>
