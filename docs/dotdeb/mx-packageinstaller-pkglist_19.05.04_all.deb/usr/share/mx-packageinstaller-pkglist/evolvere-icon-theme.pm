<?xml version="1.0"?>
<app>

<category>
Icons
</category>

<name>
Evolvere Icon Themes
</name>

<description>
   <am>evolvere icons (vibrant)</am>
   <ar>evolvere icons (vibrant)</ar>
   <bg>evolvere icons (vibrant)</bg>
   <ca>evolvere icons (vibrant)</ca>
   <cs>evolvere icons (vibrant)</cs>
   <da>evolvere-ikoner (farverige)</da>
   <de>Symbolthema Evolvere</de>
   <el>εικονίδια evolvere (ζωντανή)</el>
   <en>evolvere icons (vibrant)</en>
   <es>evolvere icons (vibrant)</es>
   <et>evolvere icons (vibrant)</et>
   <eu>evolvere icons (vibrant)</eu>
   <fa>evolvere icons (vibrant)</fa>
   <fi>evolvere icons (vibrant)</fi>
   <fr>icônes evolvere (dynamiques)</fr>
   <he_IL>evolvere icons (vibrant)</he_IL>
   <hi>evolvere icons (vibrant)</hi>
   <hr>evolvere icons (vibrant)</hr>
   <hu>evolvere icons (vibrant)</hu>
   <id>evolvere icons (vibrant)</id>
   <is>evolvere icons (vibrant)</is>
   <it>icone evolvere (vibrant)</it>
   <ja_JP>evolvere icons (vibrant)</ja_JP>
   <ja>evolvere icons (vibrant)</ja>
   <kk>evolvere icons (vibrant)</kk>
   <ko>evolvere icons (vibrant)</ko>
   <lt>evolvere icons (vibrant)</lt>
   <mk>evolvere icons (vibrant)</mk>
   <nb>evolvere icons (vibrant)</nb>
   <nl>evolvere iconen (levendig)</nl>
   <pl>ikony evolvere (vibrant)</pl>
   <pt_BR>evolvere icons (vibrant)</pt_BR>
   <pt>evolvere icons (vibrant)</pt>
   <ro>evolvere icons (vibrant)</ro>
   <ru>evolvere icons (vibrant)</ru>
   <sk>evolvere icons (vibrant)</sk>
   <sl>evolvere icons (vibrant)</sl>
   <sq>evolvere icons (vibrant)</sq>
   <sr>evolvere icons (vibrant)</sr>
   <sv>evolvere ikoner (lysande)</sv>
   <tr>evolvere icons (vibrant)</tr>
   <uk>evolvere icons (vibrant)</uk>
   <zh_CN>evolvere icons (vibrant)</zh_CN>
   <zh_TW>evolvere icons (vibrant)</zh_TW>
</description>

<installable>
all
</installable>

<screenshot></screenshot>

<preinstall>

</preinstall>

<install_package_names>
evolvere-icon-theme
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
evolvere-icon-theme
</uninstall_package_names>
</app>
