<?xml version="1.0"?>
<app>

<category>
Flash
</category>

<name>
adobe flash
</name>

<description>
   <am>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</am>
   <ar>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</ar>
   <bg>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</bg>
   <ca>Adobe Flash oficial, incloent-hi extensions per Chromium (pepperflash) i Firefox</ca>
   <cs>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</cs>
   <da>Officiel Adobe Flash, inklusiv plugins til chromium (pepperflash) og firefox</da>
   <de>Offizielles Adobe-Flash-Plugin für Chromium (pepperflash) und Firefox</de>
   <el>Επίσημο Adobe Flash, συμπεριλαμβανομένων των plugin για chromium (pepperflash) και firefox</el>
   <en>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</en>
   <es>Adobe Flash oficial. Incluye plugins para chromium (pepperflash) y firefox</es>
   <et>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</et>
   <eu>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</eu>
   <fa>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</fa>
   <fi>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</fi>
   <fr>Adobe Flash officiel, incluant plugins pour Chromium (pepperflash) et Firefox</fr>
   <he_IL>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</he_IL>
   <hi>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</hi>
   <hr>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</hr>
   <hu>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</hu>
   <id>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</id>
   <is>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</is>
   <it>Adobe Flash ufficiale, contenente plugins per chromium (pepperflash) e firefox</it>
   <ja_JP>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</ja_JP>
   <ja>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</ja>
   <kk>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</kk>
   <ko>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</ko>
   <lt>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</lt>
   <mk>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</mk>
   <nb>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</nb>
   <nl>Officiële Adobe Flash, inclusief plugins voor chromium (pepperflash) en firefox</nl>
   <pl>oficjalny Adobe Flash, w tym wtyczki do Chromium (Pepperflash) i Firefoksa</pl>
   <pt_BR>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</pt_BR>
   <pt>Adobe Flash oficial que inclui suplementos (plugins) para chromium (pepperflash) e firefox</pt>
   <ro>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</ro>
   <ru>Официальный Adobe Flash, включающий плагины для Chromium (pepperflash) и Firefox</ru>
   <sk>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</sk>
   <sl>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</sl>
   <sq>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</sq>
   <sr>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</sr>
   <sv>Officiell Adobe Flash, inkluderande plugins för chromium (pepperflash) och firefox</sv>
   <tr>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</tr>
   <uk>Офіційний Adobe Flash, включно з плагінами для chromium (pepperflash) та firefox</uk>
   <zh_CN>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</zh_CN>
   <zh_TW>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
adobe-flashplugin
adobe-flash-properties-gtk
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
adobe-flashplugin
adobe-flash-properties-gtk
</uninstall_package_names>
</app>
