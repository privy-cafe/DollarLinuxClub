<?xml version="1.0"?>
<app>

<category>
Graphics
</category>

<name>
font-manager
</name>

<description>
   <am>font management application from the GNOME desktop</am>
   <ar>font management application from the GNOME desktop</ar>
   <bg>font management application from the GNOME desktop</bg>
   <ca>font management application from the GNOME desktop</ca>
   <cs>font management application from the GNOME desktop</cs>
   <da>font management application from the GNOME desktop</da>
   <de>font management application from the GNOME desktop</de>
   <el>font management application from the GNOME desktop</el>
   <en>font management application from the GNOME desktop</en>
   <es>font management application from the GNOME desktop</es>
   <et>font management application from the GNOME desktop</et>
   <eu>font management application from the GNOME desktop</eu>
   <fa>font management application from the GNOME desktop</fa>
   <fi>font management application from the GNOME desktop</fi>
   <fr>font management application from the GNOME desktop</fr>
   <he_IL>font management application from the GNOME desktop</he_IL>
   <hi>font management application from the GNOME desktop</hi>
   <hr>font management application from the GNOME desktop</hr>
   <hu>font management application from the GNOME desktop</hu>
   <id>font management application from the GNOME desktop</id>
   <is>font management application from the GNOME desktop</is>
   <it>font management application from the GNOME desktop</it>
   <ja_JP>font management application from the GNOME desktop</ja_JP>
   <ja>font management application from the GNOME desktop</ja>
   <kk>font management application from the GNOME desktop</kk>
   <ko>font management application from the GNOME desktop</ko>
   <lt>font management application from the GNOME desktop</lt>
   <mk>font management application from the GNOME desktop</mk>
   <nb>font management application from the GNOME desktop</nb>
   <nl>font management application from the GNOME desktop</nl>
   <pl>font management application from the GNOME desktop</pl>
   <pt_BR>font management application from the GNOME desktop</pt_BR>
   <pt>font management application from the GNOME desktop</pt>
   <ro>font management application from the GNOME desktop</ro>
   <ru>font management application from the GNOME desktop</ru>
   <sk>font management application from the GNOME desktop</sk>
   <sl>font management application from the GNOME desktop</sl>
   <sq>font management application from the GNOME desktop</sq>
   <sr>font management application from the GNOME desktop</sr>
   <sv>font management application from the GNOME desktop</sv>
   <tr>font management application from the GNOME desktop</tr>
   <uk>font management application from the GNOME desktop</uk>
   <zh_CN>font management application from the GNOME desktop</zh_CN>
   <zh_TW>font management application from the GNOME desktop</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/014/272/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
font-manager
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
font-manager
</uninstall_package_names>
</app>
