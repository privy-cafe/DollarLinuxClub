<?xml version="1.0"?>
<app>

<category>
Server
</category>

<name>
Local Web Server
</name>

<description>
   <am>apache2, php7, mariaDB</am>
   <ar>apache2, php7, mariaDB</ar>
   <bg>apache2, php7, mariaDB</bg>
   <ca>apache2, php7, mariaDB</ca>
   <cs>apache2, php7, mariaDB</cs>
   <da>apache2, php7, mariaDB</da>
   <de>Apache2, PHP7, MariaDB</de>
   <el>apache2, php7, mariaDB</el>
   <en>apache2, php7, mariaDB</en>
   <es>apache2, php7, mariaDB</es>
   <et>apache2, php7, mariaDB</et>
   <eu>apache2, php7, mariaDB</eu>
   <fa>apache2, php7, mariaDB</fa>
   <fi>apache2, php7, mariaDB</fi>
   <fr>apache2, php7, mariaDB</fr>
   <he_IL>apache2, php7, mariaDB</he_IL>
   <hi>apache2, php7, mariaDB</hi>
   <hr>apache2, php7, mariaDB</hr>
   <hu>apache2, php7, mariaDB</hu>
   <id>apache2, php7, mariaDB</id>
   <is>apache2, php7, mariaDB</is>
   <it>apache2, php7, mariaDB</it>
   <ja_JP>apache2, php7, mariaDB</ja_JP>
   <ja>apache2, php7, mariaDB</ja>
   <kk>apache2, php7, mariaDB</kk>
   <ko>apache2, php7, mariaDB</ko>
   <lt>apache2, php7, mariaDB</lt>
   <mk>apache2, php7, mariaDB</mk>
   <nb>apache2, php7, mariaDB</nb>
   <nl>apache2, php7, mariaDB</nl>
   <pl>Apache2, PHP7, MariaDB</pl>
   <pt_BR>apache2, php7, mariaDB</pt_BR>
   <pt>apache2, php7, mariaDB</pt>
   <ro>apache2, php7, mariaDB</ro>
   <ru>ПО веб-сервера: apache2, php7, mariaDB</ru>
   <sk>apache2, php7, mariaDB</sk>
   <sl>apache2, php7, mariaDB</sl>
   <sq>apache2, php7, mariaDB</sq>
   <sr>apache2, php7, mariaDB</sr>
   <sv>apache2, php7, mariaDB</sv>
   <tr>apache2, php7, mariaDB</tr>
   <uk>apache2, php7, mariaDB</uk>
   <zh_CN>apache2, php7, mariaDB</zh_CN>
   <zh_TW>apache2, php7, mariaDB</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
apache2
apache2-utils
curl
mariadb-server
mariadb-client
php7.0
libapache2-mod-php7.0
php7.0-mysql
php-common
php7.0-cli
php7.0-common
php7.0-json
php7.0-opcache
php7.0-readline
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
apache2
apache2-utils
curl
mariadb-server
mariadb-client
php7.0
libapache2-mod-php7.0
php7.0-mysql
php-common
php7.0-cli
php7.0-common
php7.0-json
php7.0-opcache
php7.0-readline
</uninstall_package_names>
</app>
