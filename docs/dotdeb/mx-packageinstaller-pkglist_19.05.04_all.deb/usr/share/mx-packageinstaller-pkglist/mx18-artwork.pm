<?xml version="1.0"?>
<app>

<category>
Wallpapers
</category>

<name>
MX 18 Wallpapers
</name>

<description>
   <am>backgrounds originally supplied with MX 18</am>
   <ar>backgrounds originally supplied with MX 18</ar>
   <bg>backgrounds originally supplied with MX 18</bg>
   <ca>backgrounds originally supplied with MX 18</ca>
   <cs>backgrounds originally supplied with MX 18</cs>
   <da>baggrunde fra MX 18</da>
   <de>Bildschirmhintergründe, die ursprünglich mit MX 18 geliefert wurden</de>
   <el>επιφάνεια εργασίας που παρέχεται αρχικά με MX 18</el>
   <en>backgrounds originally supplied with MX 18</en>
   <es>backgrounds originally supplied with MX 18</es>
   <et>backgrounds originally supplied with MX 18</et>
   <eu>backgrounds originally supplied with MX 18</eu>
   <fa>backgrounds originally supplied with MX 18</fa>
   <fi>backgrounds originally supplied with MX 18</fi>
   <fr>Fonds d'écran initialement fournis avec MX 18</fr>
   <he_IL>backgrounds originally supplied with MX 18</he_IL>
   <hi>backgrounds originally supplied with MX 18</hi>
   <hr>backgrounds originally supplied with MX 18</hr>
   <hu>backgrounds originally supplied with MX 18</hu>
   <id>backgrounds originally supplied with MX 18</id>
   <is>backgrounds originally supplied with MX 18</is>
   <it>sfondi originariamente forniti con MX 18</it>
   <ja_JP>backgrounds originally supplied with MX 18</ja_JP>
   <ja>backgrounds originally supplied with MX 18</ja>
   <kk>backgrounds originally supplied with MX 18</kk>
   <ko>backgrounds originally supplied with MX 18</ko>
   <lt>backgrounds originally supplied with MX 18</lt>
   <mk>backgrounds originally supplied with MX 18</mk>
   <nb>backgrounds originally supplied with MX 18</nb>
   <nl>achtergronden oorspronkelijk geleverd met MX 18</nl>
   <pl>tła oryginalnie dostarczone z MX 18</pl>
   <pt_BR>backgrounds originally supplied with MX 18</pt_BR>
   <pt>backgrounds originally supplied with MX 18</pt>
   <ro>backgrounds originally supplied with MX 18</ro>
   <ru>Обои первоначально входившие в MX 18</ru>
   <sk>backgrounds originally supplied with MX 18</sk>
   <sl>backgrounds originally supplied with MX 18</sl>
   <sq>backgrounds originally supplied with MX 18</sq>
   <sr>backgrounds originally supplied with MX 18</sr>
   <sv>wallpapers ursprungligen medföljande MX 18</sv>
   <tr>backgrounds originally supplied with MX 18</tr>
   <uk>backgrounds originally supplied with MX 18</uk>
   <zh_CN>backgrounds originally supplied with MX 18</zh_CN>
   <zh_TW>backgrounds originally supplied with MX 18</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
mx18-artwork
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
mx18-artwork
</uninstall_package_names>
</app>
