<?xml version="1.0"?>
<app>

<category>
Browser
</category>

<name>
Netsurf
</name>

<description>
   <am>Latest Netsurf Browser</am>
   <ar>Latest Netsurf Browser</ar>
   <bg>Latest Netsurf Browser</bg>
   <ca>Darrer navegador Netsurf</ca>
   <cs>Latest Netsurf Browser</cs>
   <da>Seneste Netsurf-browser</da>
   <de>Aktueller Netsurf-Browser</de>
   <el>Τελευταίο πρόγραμμα περιήγησης Netsurf</el>
   <en>Latest Netsurf Browser</en>
   <es>navegador Netsurf actualizado</es>
   <et>Latest Netsurf Browser</et>
   <eu>Latest Netsurf Browser</eu>
   <fa>Latest Netsurf Browser</fa>
   <fi>Latest Netsurf Browser</fi>
   <fr>La dernière version du navigateur Netsurf</fr>
   <he_IL>Latest Netsurf Browser</he_IL>
   <hi>Latest Netsurf Browser</hi>
   <hr>Latest Netsurf Browser</hr>
   <hu>Latest Netsurf Browser</hu>
   <id>Latest Netsurf Browser</id>
   <is>Latest Netsurf Browser</is>
   <it>Ultimo browser Netsurf</it>
   <ja_JP>Latest Netsurf Browser</ja_JP>
   <ja>Latest Netsurf Browser</ja>
   <kk>Latest Netsurf Browser</kk>
   <ko>Latest Netsurf Browser</ko>
   <lt>Latest Netsurf Browser</lt>
   <mk>Latest Netsurf Browser</mk>
   <nb>Latest Netsurf Browser</nb>
   <nl>Meest Recente Netsurf Browser</nl>
   <pl>najnowsza przeglądarka Netsurf</pl>
   <pt_BR>Latest Netsurf Browser</pt_BR>
   <pt>Navegador web Netsurf, versão mais recente</pt>
   <ro>Latest Netsurf Browser</ro>
   <ru>Браузер Netsurf последней версии</ru>
   <sk>Latest Netsurf Browser</sk>
   <sl>Latest Netsurf Browser</sl>
   <sq>Latest Netsurf Browser</sq>
   <sr>Latest Netsurf Browser</sr>
   <sv>Senaste Netsurf Webbläsare</sv>
   <tr>Latest Netsurf Browser</tr>
   <uk>Крайня версія браузера Netsurf</uk>
   <zh_CN>Latest Netsurf Browser</zh_CN>
   <zh_TW>Latest Netsurf Browser</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
netsurf
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
netsurf
</uninstall_package_names>
</app>
