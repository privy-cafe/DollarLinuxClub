<?xml version="1.0"?>
<app>

<category>
Office
</category>

<name>
Dictionary
</name>

<description>
   <am>OpenDict Dictionary</am>
   <ar>OpenDict Dictionary</ar>
   <bg>OpenDict Dictionary</bg>
   <ca>Diccionari OpenDict</ca>
   <cs>OpenDict Dictionary</cs>
   <da>OpenDict-ordbog</da>
   <de>OpenDict Wörterbuch</de>
   <el>Λεξικό OpenDict</el>
   <en>OpenDict Dictionary</en>
   <es>Diccionario OpenDict</es>
   <et>OpenDict Dictionary</et>
   <eu>OpenDict Dictionary</eu>
   <fa>OpenDict Dictionary</fa>
   <fi>OpenDict Dictionary</fi>
   <fr>Dictionnaire OpenDict</fr>
   <he_IL>OpenDict Dictionary</he_IL>
   <hi>OpenDict Dictionary</hi>
   <hr>OpenDict Dictionary</hr>
   <hu>OpenDict Dictionary</hu>
   <id>OpenDict Dictionary</id>
   <is>OpenDict Dictionary</is>
   <it>Dizionario OpenDict</it>
   <ja_JP>OpenDict Dictionary</ja_JP>
   <ja>OpenDict Dictionary</ja>
   <kk>OpenDict Dictionary</kk>
   <ko>OpenDict Dictionary</ko>
   <lt>OpenDict žodynas</lt>
   <mk>OpenDict Dictionary</mk>
   <nb>OpenDict Dictionary</nb>
   <nl>OpenDict Woordenboek</nl>
   <pl>słownik OpenDict</pl>
   <pt_BR>OpenDict Dictionary</pt_BR>
   <pt>Dicionário OpenDict</pt>
   <ro>OpenDict Dictionary</ro>
   <ru>Словарь OpenDict</ru>
   <sk>OpenDict Dictionary</sk>
   <sl>OpenDict Dictionary</sl>
   <sq>OpenDict Dictionary</sq>
   <sr>OpenDict Dictionary</sr>
   <sv>OpenDict Ordbok</sv>
   <tr>OpenDict Dictionary</tr>
   <uk>Словник OpenDict</uk>
   <zh_CN>OpenDict Dictionary</zh_CN>
   <zh_TW>OpenDict Dictionary</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
opendict
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
opendict
</uninstall_package_names>
</app>
