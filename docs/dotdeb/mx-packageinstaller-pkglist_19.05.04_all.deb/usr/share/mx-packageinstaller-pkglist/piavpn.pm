<?xml version="1.0"?>
<app>

<category>
Network
</category>

<name>
PIAVPN - Private Internet Access VPN
</name>

<description>
   <am>Private Internet Access VPN and sysVinit scripts</am>
   <ar>Private Internet Access VPN and sysVinit scripts</ar>
   <bg>Private Internet Access VPN and sysVinit scripts</bg>
   <ca>Private Internet Access VPN and sysVinit scripts</ca>
   <cs>Private Internet Access VPN and sysVinit scripts</cs>
   <da>Private Internet Access VPN and sysVinit scripts</da>
   <de>Private Internet Access VPN and sysVinit scripts</de>
   <el>Private Internet Access VPN and sysVinit scripts</el>
   <en>Private Internet Access VPN and sysVinit scripts</en>
   <es>Private Internet Access VPN and sysVinit scripts</es>
   <et>Private Internet Access VPN and sysVinit scripts</et>
   <eu>Private Internet Access VPN and sysVinit scripts</eu>
   <fa>Private Internet Access VPN and sysVinit scripts</fa>
   <fi>Private Internet Access VPN and sysVinit scripts</fi>
   <fr>Private Internet Access VPN and sysVinit scripts</fr>
   <he_IL>Private Internet Access VPN and sysVinit scripts</he_IL>
   <hi>Private Internet Access VPN and sysVinit scripts</hi>
   <hr>Private Internet Access VPN and sysVinit scripts</hr>
   <hu>Private Internet Access VPN and sysVinit scripts</hu>
   <id>Private Internet Access VPN and sysVinit scripts</id>
   <is>Private Internet Access VPN and sysVinit scripts</is>
   <it>Private Internet Access VPN and sysVinit scriptsv</it>
   <ja_JP>Private Internet Access VPN and sysVinit scripts</ja_JP>
   <ja>Private Internet Access VPN and sysVinit scripts</ja>
   <kk>Private Internet Access VPN and sysVinit scripts</kk>
   <ko>Private Internet Access VPN and sysVinit scripts</ko>
   <lt>Private Internet Access VPN and sysVinit scripts</lt>
   <mk>Private Internet Access VPN and sysVinit scripts</mk>
   <nb>Private Internet Access VPN and sysVinit scripts</nb>
   <nl>Private Internet Access VPN and sysVinit scripts</nl>
   <pl>Private Internet Access VPN and sysVinit scripts</pl>
   <pt_BR>Private Internet Access VPN and sysVinit scripts</pt_BR>
   <pt>Private Internet Access VPN and sysVinit scripts</pt>
   <ro>Private Internet Access VPN and sysVinit scripts</ro>
   <ru>Private Internet Access VPN and sysVinit scripts</ru>
   <sk>Private Internet Access VPN and sysVinit scripts</sk>
   <sl>Private Internet Access VPN and sysVinit scripts</sl>
   <sq>Private Internet Access VPN and sysVinit scripts</sq>
   <sr>Private Internet Access VPN and sysVinit scripts</sr>
   <sv>Private Internet Access VPN and sysVinit scripts</sv>
   <tr>Private Internet Access VPN and sysVinit scripts</tr>
   <uk>Private Internet Access VPN and sysVinit scripts</uk>
   <zh_CN>Private Internet Access VPN and sysVinit scripts</zh_CN>
   <zh_TW>Private Internet Access VPN and sysVinit scripts</zh_TW>
</description>

<installable>
64
</installable>

<screenshot>none</screenshot>

<preinstall>
apt install --reinstall piavpn-downloader-installer
</preinstall>

<install_package_names>
piavpn-sysvinit-compat
</install_package_names>

<postinstall>

</postinstall>

<uninstall_package_names>
piavpn-sysvinit-compat
piavpn-downloader-installer
</uninstall_package_names>
</app>
