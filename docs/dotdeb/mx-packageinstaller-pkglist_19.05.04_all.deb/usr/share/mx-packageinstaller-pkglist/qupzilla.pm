<?xml version="1.0"?>
<app>

<category>
Browser
</category>

<name>
Qupzilla
</name>

<description>
   <am>Latest Qupzilla lightweight browser</am>
   <ar>Latest Qupzilla lightweight browser</ar>
   <bg>Latest Qupzilla lightweight browser</bg>
   <ca>Darrera versió del navegador lleuger Qupzilla</ca>
   <cs>Latest Qupzilla lightweight browser</cs>
   <da>Seneste Qupzilla letvægtsbrowser</da>
   <de>Neuester Qupzilla leichtgewichtiger Browser</de>
   <el>Τελευταίο ελαφρύ πρόγραμμα περιήγησης Qupzilla</el>
   <en>Latest Qupzilla lightweight browser</en>
   <es>Navegador liviano Qupzilla actualizado</es>
   <et>Latest Qupzilla lightweight browser</et>
   <eu>Latest Qupzilla lightweight browser</eu>
   <fa>Latest Qupzilla lightweight browser</fa>
   <fi>Latest Qupzilla lightweight browser</fi>
   <fr>La dernière version du navigateur léger Qupzilla</fr>
   <he_IL>Latest Qupzilla lightweight browser</he_IL>
   <hi>Latest Qupzilla lightweight browser</hi>
   <hr>Latest Qupzilla lightweight browser</hr>
   <hu>Latest Qupzilla lightweight browser</hu>
   <id>Latest Qupzilla lightweight browser</id>
   <is>Latest Qupzilla lightweight browser</is>
   <it>L'ultima versione del browser leggero Qupzilla</it>
   <ja_JP>Latest Qupzilla lightweight browser</ja_JP>
   <ja>Latest Qupzilla lightweight browser</ja>
   <kk>Latest Qupzilla lightweight browser</kk>
   <ko>Latest Qupzilla lightweight browser</ko>
   <lt>Naujausia Qupzilla supaprastinta naršyklė</lt>
   <mk>Latest Qupzilla lightweight browser</mk>
   <nb>Latest Qupzilla lightweight browser</nb>
   <nl>Meest recente Qupzilla lichtgewicht browser</nl>
   <pl>najnowsza lekka przeglądarka Qupzilla</pl>
   <pt_BR>Latest Qupzilla lightweight browser</pt_BR>
   <pt>Navegador web ligeiro Qupzilla, versão mais recente</pt>
   <ro>Latest Qupzilla lightweight browser</ro>
   <ru>Легковесный браузер Qupzilla последней версии</ru>
   <sk>Latest Qupzilla lightweight browser</sk>
   <sl>Latest Qupzilla lightweight browser</sl>
   <sq>Latest Qupzilla lightweight browser</sq>
   <sr>Latest Qupzilla lightweight browser</sr>
   <sv>Senaste Qupzilla lättviktswebbläsare</sv>
   <tr>Latest Qupzilla lightweight browser</tr>
   <uk>Latest Qupzilla lightweight browser</uk>
   <zh_CN>Latest Qupzilla lightweight browser</zh_CN>
   <zh_TW>Latest Qupzilla lightweight browser</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/015/301/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
qupzilla
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
qupzilla
</uninstall_package_names>
</app>
