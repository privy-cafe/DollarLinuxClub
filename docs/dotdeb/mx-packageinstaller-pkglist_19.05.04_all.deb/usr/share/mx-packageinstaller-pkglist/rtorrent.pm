<?xml version="1.0"?>
<app>

<category>
Torrent
</category>

<name>
rTorrent
</name>

<description>
   <am>an ncurses BitTorrent client</am>
   <ar>an ncurses BitTorrent client</ar>
   <bg>an ncurses BitTorrent client</bg>
   <ca>Un client de BitTorrent en ncurses</ca>
   <cs>an ncurses BitTorrent client</cs>
   <da>en ncurses BitTorrent-klient</da>
   <de>Ein mit ncurses realisierter BitTorrent-Client</de>
   <el>ένα ncurses BitTorrent πελάτη</el>
   <en>an ncurses BitTorrent client</en>
   <es>an ncurses BitTorrent client</es>
   <et>an ncurses BitTorrent client</et>
   <eu>an ncurses BitTorrent client</eu>
   <fa>an ncurses BitTorrent client</fa>
   <fi>an ncurses BitTorrent client</fi>
   <fr>Client BitTorrent ncurses</fr>
   <he_IL>an ncurses BitTorrent client</he_IL>
   <hi>an ncurses BitTorrent client</hi>
   <hr>an ncurses BitTorrent client</hr>
   <hu>an ncurses BitTorrent client</hu>
   <id>an ncurses BitTorrent client</id>
   <is>an ncurses BitTorrent client</is>
   <it>client BitTorrent che usa ncurses</it>
   <ja_JP>an ncurses BitTorrent client</ja_JP>
   <ja>an ncurses BitTorrent client</ja>
   <kk>an ncurses BitTorrent client</kk>
   <ko>an ncurses BitTorrent client</ko>
   <lt>an ncurses BitTorrent client</lt>
   <mk>an ncurses BitTorrent client</mk>
   <nb>an ncurses BitTorrent client</nb>
   <nl>een ncurses BitTorrent programma</nl>
   <pl>klient ncurses BitTorrent</pl>
   <pt_BR>an ncurses BitTorrent client</pt_BR>
   <pt>Cliente de BitTorrent baseado em ncurses</pt>
   <ro>an ncurses BitTorrent client</ro>
   <ru>Клиент BitTorrent с интерфейсом на ncurses</ru>
   <sk>an ncurses BitTorrent client</sk>
   <sl>an ncurses BitTorrent client</sl>
   <sq>an ncurses BitTorrent client</sq>
   <sr>an ncurses BitTorrent client</sr>
   <sv>en ncurses BitTorrent klient</sv>
   <tr>an ncurses BitTorrent client</tr>
   <uk>консольний BitTorrent клієнт</uk>
   <zh_CN>an ncurses BitTorrent client</zh_CN>
   <zh_TW>an ncurses BitTorrent client</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/001/284/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
rtorrent
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
rtorrent
</uninstall_package_names>
</app>
