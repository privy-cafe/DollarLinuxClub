<?xml version="1.0"?>
<app>


<category>
Screenshot Utilities
</category>

<name>
Shutter
</name>

<description>
   <am>a feature rich screenshot app</am>
   <ar>a feature rich screenshot app</ar>
   <bg>a feature rich screenshot app</bg>
   <ca>Aplicació de captura de pantalla amb moltes característiques</ca>
   <cs>a feature rich screenshot app</cs>
   <da>et skærmbilledprogram med det hele</da>
   <de>Eine funktionsreiche Screenshot-Anwendung</de>
   <el>μια εφαρμογή πλούσια σε στιγμιότυπα οθόνης</el>
   <en>a feature rich screenshot app</en>
   <es>app de captura de pantalla rica en funcionalidades</es>
   <et>a feature rich screenshot app</et>
   <eu>a feature rich screenshot app</eu>
   <fa>a feature rich screenshot app</fa>
   <fi>a feature rich screenshot app</fi>
   <fr>Un outil complet de capture d'écran</fr>
   <he_IL>a feature rich screenshot app</he_IL>
   <hi>a feature rich screenshot app</hi>
   <hr>a feature rich screenshot app</hr>
   <hu>a feature rich screenshot app</hu>
   <id>a feature rich screenshot app</id>
   <is>a feature rich screenshot app</is>
   <it>applicazione per catturare lo schermo, ricca di funzioni.</it>
   <ja_JP>a feature rich screenshot app</ja_JP>
   <ja>a feature rich screenshot app</ja>
   <kk>a feature rich screenshot app</kk>
   <ko>a feature rich screenshot app</ko>
   <lt>a feature rich screenshot app</lt>
   <mk>a feature rich screenshot app</mk>
   <nb>a feature rich screenshot app</nb>
   <nl>een functie rijke screenshot app</nl>
   <pl>funkcjonalna aplikacja do wykonywania zrzutów ekranu</pl>
   <pt_BR>a feature rich screenshot app</pt_BR>
   <pt>Aplicação de captura de ecrã plena de funcionalidades</pt>
   <ro>a feature rich screenshot app</ro>
   <ru>Функциональное приложение захвата снимков экрана</ru>
   <sk>a feature rich screenshot app</sk>
   <sl>a feature rich screenshot app</sl>
   <sq>a feature rich screenshot app</sq>
   <sr>a feature rich screenshot app</sr>
   <sv>en skärmdumpsapp med många möjligheter</sv>
   <tr>a feature rich screenshot app</tr>
   <uk>a feature rich screenshot app</uk>
   <zh_CN>a feature rich screenshot app</zh_CN>
   <zh_TW>a feature rich screenshot app</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>http://shutter-project.org/wp-content/uploads/key_feature_030.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
shutter
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
shutter
</uninstall_package_names>

</app>
