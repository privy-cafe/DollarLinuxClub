<?xml version="1.0"?>
<app>

<category>
Video
</category>

<name>
SMtube
</name>

<description>
   <am>search and download Youtube videos</am>
   <ar>search and download Youtube videos</ar>
   <bg>search and download Youtube videos</bg>
   <ca>Cerca i descarrega vídeos de Youtube</ca>
   <cs>search and download Youtube videos</cs>
   <da>søg efter og download Youtube-videoer</da>
   <de>YouTube-Videos finden und herunterladen</de>
   <el>αναζήτηση και λήψη βίντεο Youtube</el>
   <en>search and download Youtube videos</en>
   <es>Busque y descargue videos de Youtube</es>
   <et>search and download Youtube videos</et>
   <eu>search and download Youtube videos</eu>
   <fa>search and download Youtube videos</fa>
   <fi>search and download Youtube videos</fi>
   <fr>Rechercher et télécharger des vidéos Youtube</fr>
   <he_IL>search and download Youtube videos</he_IL>
   <hi>search and download Youtube videos</hi>
   <hr>search and download Youtube videos</hr>
   <hu>search and download Youtube videos</hu>
   <id>search and download Youtube videos</id>
   <is>search and download Youtube videos</is>
   <it>cerca e scarica video da Youtube</it>
   <ja_JP>search and download Youtube videos</ja_JP>
   <ja>search and download Youtube videos</ja>
   <kk>search and download Youtube videos</kk>
   <ko>search and download Youtube videos</ko>
   <lt>search and download Youtube videos</lt>
   <mk>search and download Youtube videos</mk>
   <nb>search and download Youtube videos</nb>
   <nl>zoek en download Youtube video's</nl>
   <pl>wyszukuj i pobieraj filmy z YouTube</pl>
   <pt_BR>search and download Youtube videos</pt_BR>
   <pt>pesquisar e descarregar vídeos do Youtube</pt>
   <ro>search and download Youtube videos</ro>
   <ru>Поиск и скачивание видео в Youtube</ru>
   <sk>search and download Youtube videos</sk>
   <sl>search and download Youtube videos</sl>
   <sq>search and download Youtube videos</sq>
   <sr>search and download Youtube videos</sr>
   <sv>sök och ladda ner Youtube videos</sv>
   <tr>search and download Youtube videos</tr>
   <uk>пошук та завантаження відео з Youtube</uk>
   <zh_CN>search and download Youtube videos</zh_CN>
   <zh_TW>search and download Youtube videos</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/010/334/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
smtube
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
smtube
</uninstall_package_names>
</app>
