<?xml version="1.0"?>
<app>

<category>
Screensaver
</category>

<name>
additional screensavers
</name>

<description>
   <am>extra screensavers (requires xscreensaver)</am>
   <ar>extra screensavers (requires xscreensaver)</ar>
   <bg>extra screensavers (requires xscreensaver)</bg>
   <ca>extra screensavers (requires xscreensaver)</ca>
   <cs>extra screensavers (requires xscreensaver)</cs>
   <da>ekstra pauseskærme (kræver xscreensaver)</da>
   <de>zusätzliche Bildschirmschoner (xscreensaver erforderlich)</de>
   <el>επιπλέον προφύλαξη οθόνης (απαιτεί xscreensaver)</el>
   <en>extra screensavers (requires xscreensaver)</en>
   <es>extra screensavers (requires xscreensaver)</es>
   <et>extra screensavers (requires xscreensaver)</et>
   <eu>extra screensavers (requires xscreensaver)</eu>
   <fa>extra screensavers (requires xscreensaver)</fa>
   <fi>extra screensavers (requires xscreensaver)</fi>
   <fr>écrans de veille supplémentaires (requiert xscreensaver)</fr>
   <he_IL>extra screensavers (requires xscreensaver)</he_IL>
   <hi>extra screensavers (requires xscreensaver)</hi>
   <hr>extra screensavers (requires xscreensaver)</hr>
   <hu>extra screensavers (requires xscreensaver)</hu>
   <id>extra screensavers (requires xscreensaver)</id>
   <is>extra screensavers (requires xscreensaver)</is>
   <it>salvaschermi extra (richiede xscreensaver)</it>
   <ja_JP>extra screensavers (requires xscreensaver)</ja_JP>
   <ja>extra screensavers (requires xscreensaver)</ja>
   <kk>extra screensavers (requires xscreensaver)</kk>
   <ko>extra screensavers (requires xscreensaver)</ko>
   <lt>extra screensavers (requires xscreensaver)</lt>
   <mk>extra screensavers (requires xscreensaver)</mk>
   <nb>extra screensavers (requires xscreensaver)</nb>
   <nl>extra screensavers (vereist xscreensaver)</nl>
   <pl>dodatkowe wygaszacze ekranu (wymaga xscreensaver)</pl>
   <pt_BR>extra screensavers (requires xscreensaver)</pt_BR>
   <pt>extra screensavers (requires xscreensaver)</pt>
   <ro>extra screensavers (requires xscreensaver)</ro>
   <ru>дополнительные заставки экрана (требует установленного xscreensaver)</ru>
   <sk>extra screensavers (requires xscreensaver)</sk>
   <sl>extra screensavers (requires xscreensaver)</sl>
   <sq>extra screensavers (requires xscreensaver)</sq>
   <sr>extra screensavers (requires xscreensaver)</sr>
   <sv>extra skärmsläckare (kräver xscreensaver)</sv>
   <tr>extra screensavers (requires xscreensaver)</tr>
   <uk>extra screensavers (requires xscreensaver)</uk>
   <zh_CN>extra screensavers (requires xscreensaver)</zh_CN>
   <zh_TW>extra screensavers (requires xscreensaver)</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
xscreensaver-data-extra
xscreensaver-screensaver-bsod
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
xscreensaver-data-extra
xscreensaver-screensaver-bsod
</uninstall_package_names>
</app>
