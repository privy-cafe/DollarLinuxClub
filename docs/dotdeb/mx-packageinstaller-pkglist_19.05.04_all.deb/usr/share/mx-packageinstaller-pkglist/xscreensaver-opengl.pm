<?xml version="1.0"?>
<app>

<category>
Screensaver
</category>

<name>
openGL screensavers
</name>

<description>
   <am>extra opengl screensavers (requires xscreensaver)</am>
   <ar>extra opengl screensavers (requires xscreensaver)</ar>
   <bg>extra opengl screensavers (requires xscreensaver)</bg>
   <ca>extra opengl screensavers (requires xscreensaver)</ca>
   <cs>extra opengl screensavers (requires xscreensaver)</cs>
   <da>ekstra opengl-pauseskærme (kræver xscreensaver)</da>
   <de>zusätzliche opengl Bildschirmschoner (xscreensaver erforderlich)</de>
   <el>επιπλέον προφύλαξη οθόνης opengl (απαιτεί xscreensaver)</el>
   <en>extra opengl screensavers (requires xscreensaver)</en>
   <es>extra opengl screensavers (requires xscreensaver)</es>
   <et>extra opengl screensavers (requires xscreensaver)</et>
   <eu>extra opengl screensavers (requires xscreensaver)</eu>
   <fa>extra opengl screensavers (requires xscreensaver)</fa>
   <fi>extra opengl screensavers (requires xscreensaver)</fi>
   <fr>écran de veille opengl supplémentaires (requiert xscreensaver)</fr>
   <he_IL>extra opengl screensavers (requires xscreensaver)</he_IL>
   <hi>extra opengl screensavers (requires xscreensaver)</hi>
   <hr>extra opengl screensavers (requires xscreensaver)</hr>
   <hu>extra opengl screensavers (requires xscreensaver)</hu>
   <id>extra opengl screensavers (requires xscreensaver)</id>
   <is>extra opengl screensavers (requires xscreensaver)</is>
   <it>salvaschermi extra opengl (richiede xscreensaver)</it>
   <ja_JP>extra opengl screensavers (requires xscreensaver)</ja_JP>
   <ja>extra opengl screensavers (requires xscreensaver)</ja>
   <kk>extra opengl screensavers (requires xscreensaver)</kk>
   <ko>extra opengl screensavers (requires xscreensaver)</ko>
   <lt>extra opengl screensavers (requires xscreensaver)</lt>
   <mk>extra opengl screensavers (requires xscreensaver)</mk>
   <nb>extra opengl screensavers (requires xscreensaver)</nb>
   <nl>extra opengl screensavers (vereist xscreensaver)</nl>
   <pl>dodatkowe wygaszacze ekranu openGL (wymaga xscreensaver)</pl>
   <pt_BR>extra opengl screensavers (requires xscreensaver)</pt_BR>
   <pt>extra opengl screensavers (requires xscreensaver)</pt>
   <ro>extra opengl screensavers (requires xscreensaver)</ro>
   <ru>экстра opengl заставки экрана (требует установленного xscreensaver)</ru>
   <sk>extra opengl screensavers (requires xscreensaver)</sk>
   <sl>extra opengl screensavers (requires xscreensaver)</sl>
   <sq>extra opengl screensavers (requires xscreensaver)</sq>
   <sr>extra opengl screensavers (requires xscreensaver)</sr>
   <sv>extra opengl skärmsläckare (kräver xscreensaver)</sv>
   <tr>extra opengl screensavers (requires xscreensaver)</tr>
   <uk>extra opengl screensavers (requires xscreensaver)</uk>
   <zh_CN>extra opengl screensavers (requires xscreensaver)</zh_CN>
   <zh_TW>extra opengl screensavers (requires xscreensaver)</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
xscreensaver-gl
xscreensaver-gl-extra
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
xscreensavers-gl
xscreensaver-gl-extra
</uninstall_package_names>
</app>
