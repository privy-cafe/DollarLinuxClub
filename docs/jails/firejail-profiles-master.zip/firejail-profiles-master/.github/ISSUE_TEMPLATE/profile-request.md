---
name: Profile request
about: Suggest new profiles

---

**Name of the program**
Name of the program

**Website**
Website for the program (if the program is in most major repositories, you can optionally skip this).

**Already available in stock firejail?**
Is the requested profile already available in regular firejail (that is, are you requesting an enhanced profile or a completely new profile?)?

**Additional info**
Anything else you think I should know before working on this profile.
