notify-send "Network" "Network Services are restarted!" -i /usr/share/icons/Adwaita/32x32/actions/view-refresh.png
sudo service networking restart
sudo service network-manager restart
