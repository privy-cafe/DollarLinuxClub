#!/bin/sh
sudo openvpn --config /home/monster/client.ovpn
