#notify-send "Update" "Update is starting..." -i /usr/share/pixmaps/xfce4-appfinder.xpm & paplay /usr/share/sounds/KDE-Sys-App-Positive.ogg
sudo apt update -y
sudo apt upgrade -y
sudo apt dist-upgrade -y
sudo apt full-upgrade -y
sudo apt-get autoremove -y
sudo apt-get autoclean all
#notify-send "Update" "Monster is Updated!" -i /usr/share/pixmaps/synaptic.png & paplay /usr/share/sounds/KDE-Sys-App-Positive.ogg
