rsync -av /media/backup /media/monster/My\ Book
