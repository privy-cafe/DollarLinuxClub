#!/usr/bin/env bash

sleep 10

conky-manager
