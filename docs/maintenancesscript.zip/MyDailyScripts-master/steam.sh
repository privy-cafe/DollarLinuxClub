optirun wine .wine/drive_c/Program\ Files\ \(x86\)/Steam/Steam.exe
#wine .wine/drive_c/Program\ Files\ \(x86\)/Steam/Steam.exe
