sudo openvpn --config /home/pi/client.ovpn --auth-user-pass /home/pi/auth.txt &
