<?xml version="1.0"?>
<app>

<category>
Video
</category>

<name>
mplayer
</name>

<description>
   <am>a powerful multimedia player and much more</am>
   <ar>a powerful multimedia player and much more</ar>
   <bg>a powerful multimedia player and much more</bg>
   <ca>potent reproductor multimèdia i molt més</ca>
   <cs>a powerful multimedia player and much more</cs>
   <da>en kraftfuld medieafspiller og meget mere</da>
   <de>Ein leistungsstarker Multimedia-Player und vieles mehr</de>
   <el>ένα ισχυρό πρόγραμμα αναπαραγωγής πολυμέσων και πολλά άλλα</el>
   <en>a powerful multimedia player and much more</en>
   <es>Potente reproductor multimedia y mucho más</es>
   <et>a powerful multimedia player and much more</et>
   <eu>a powerful multimedia player and much more</eu>
   <fa>a powerful multimedia player and much more</fa>
   <fi>tehokas multimediasoitin ja paljon muuta</fi>
   <fr>Un puissant lecteur multimédia et bien plus</fr>
   <he_IL>a powerful multimedia player and much more</he_IL>
   <hi>a powerful multimedia player and much more</hi>
   <hr>a powerful multimedia player and much more</hr>
   <hu>a powerful multimedia player and much more</hu>
   <id>a powerful multimedia player and much more</id>
   <is>a powerful multimedia player and much more</is>
   <it>potente lettore multimediale e molto altro</it>
   <ja_JP>a powerful multimedia player and much more</ja_JP>
   <ja>a powerful multimedia player and much more</ja>
   <kk>a powerful multimedia player and much more</kk>
   <ko>a powerful multimedia player and much more</ko>
   <lt>a powerful multimedia player and much more</lt>
   <mk>a powerful multimedia player and much more</mk>
   <mr>a powerful multimedia player and much more</mr>
   <nb>a powerful multimedia player and much more</nb>
   <nl>een krachtige multimediaspeler en nog veel meer</nl>
   <pl>potężny odtwarzacz multimedialny i wiele więcej</pl>
   <pt_BR>Poderoso reprodutor de multimídia e muito mais</pt_BR>
   <pt>Poderoso reprodutor de multimédia e muito mais</pt>
   <ro>a powerful multimedia player and much more</ro>
   <ru>Продвинутый медиаплеер и даже больше</ru>
   <sk>a powerful multimedia player and much more</sk>
   <sl>Zmogljiv večpredstavnostni predvajalnik in mnogo več</sl>
   <sq>a powerful multimedia player and much more</sq>
   <sr>a powerful multimedia player and much more</sr>
   <sv>en kraftfull multimediaspelare och mycket mer</sv>
   <tr>a powerful multimedia player and much more</tr>
   <uk>потужний мультимедія програвач і не тільки</uk>
   <zh_CN>a powerful multimedia player and much more</zh_CN>
   <zh_TW>a powerful multimedia player and much more</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/013/158/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
mplayer
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
mplayer
</uninstall_package_names>
</app>
