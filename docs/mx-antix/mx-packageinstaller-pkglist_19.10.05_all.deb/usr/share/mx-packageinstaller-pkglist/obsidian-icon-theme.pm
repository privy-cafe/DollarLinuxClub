<?xml version="1.0"?>
<app>

<category>
Icons
</category>

<name>
Obsidian Icon Theme
</name>

<description>
   <am>an updated/refreshed Faenza-ish icon theme with many colour choices</am>
   <ar>an updated/refreshed Faenza-ish icon theme with many colour choices</ar>
   <bg>an updated/refreshed Faenza-ish icon theme with many colour choices</bg>
   <ca>tema de icones actualitzat tipus Faenza amb moltes opcions de color</ca>
   <cs>an updated/refreshed Faenza-ish icon theme with many colour choices</cs>
   <da>et opdateret/genopfrisket Faenza-ish-ikontema med mange valg af farver</da>
   <de>Ein aktualisiertes/erfrischtes Faenza-ähnliches Icon-Thema mit vielen Farbvarianten</de>
   <el>ένα ενημερωμένο/ανανεωμένο θέμα του Faenza με πολλές επιλογές χρωμάτων</el>
   <en>an updated/refreshed Faenza-ish icon theme with many colour choices</en>
   <es>Tema de íconos estilo Faenza reelaborados y con múltiples colores a elección.</es>
   <et>an updated/refreshed Faenza-ish icon theme with many colour choices</et>
   <eu>an updated/refreshed Faenza-ish icon theme with many colour choices</eu>
   <fa>an updated/refreshed Faenza-ish icon theme with many colour choices</fa>
   <fi>an updated/refreshed Faenza-ish icon theme with many colour choices</fi>
   <fr>Un thème d'icônes de type Faenza remis au goût du jour, avec plusieurs choix de couleurs</fr>
   <he_IL>an updated/refreshed Faenza-ish icon theme with many colour choices</he_IL>
   <hi>an updated/refreshed Faenza-ish icon theme with many colour choices</hi>
   <hr>an updated/refreshed Faenza-ish icon theme with many colour choices</hr>
   <hu>an updated/refreshed Faenza-ish icon theme with many colour choices</hu>
   <id>an updated/refreshed Faenza-ish icon theme with many colour choices</id>
   <is>an updated/refreshed Faenza-ish icon theme with many colour choices</is>
   <it>un tema di icone basato sul tema Faenza rivisto/aggiornato con molte scelte di colore</it>
   <ja_JP>an updated/refreshed Faenza-ish icon theme with many colour choices</ja_JP>
   <ja>an updated/refreshed Faenza-ish icon theme with many colour choices</ja>
   <kk>an updated/refreshed Faenza-ish icon theme with many colour choices</kk>
   <ko>an updated/refreshed Faenza-ish icon theme with many colour choices</ko>
   <lt>an updated/refreshed Faenza-ish icon theme with many colour choices</lt>
   <mk>an updated/refreshed Faenza-ish icon theme with many colour choices</mk>
   <mr>an updated/refreshed Faenza-ish icon theme with many colour choices</mr>
   <nb>an updated/refreshed Faenza-ish icon theme with many colour choices</nb>
   <nl>een geüpdatet/verfrist icoonthema van Faenza-ish met vele kleurkeuzes</nl>
   <pl>zaktualizowany/odświeżony motyw ikon Faenza z wieloma opcjami kolorów</pl>
   <pt_BR>Tema de ícones ao estilo Faenza com muitas opções de cores, actualizado/refrescado</pt_BR>
   <pt>Tema de ícones ao estilo Faenza com muitas opções de cores, actualizado/refrescado</pt>
   <ro>an updated/refreshed Faenza-ish icon theme with many colour choices</ro>
   <ru>Обновленная тема в стиле Faenza с большим выбором цветов</ru>
   <sk>an updated/refreshed Faenza-ish icon theme with many colour choices</sk>
   <sl>Posodboljena in osvežena Faenzajevska predloga ikon z mnogobarvnim izborom</sl>
   <sq>an updated/refreshed Faenza-ish icon theme with many colour choices</sq>
   <sr>an updated/refreshed Faenza-ish icon theme with many colour choices</sr>
   <sv>ett uppdaterat/förbättrat Faenza-aktigt ikontema med många färgval</sv>
   <tr>an updated/refreshed Faenza-ish icon theme with many colour choices</tr>
   <uk>оновлена тема піктограм Faenza з великим вибором кольорів</uk>
   <zh_CN>an updated/refreshed Faenza-ish icon theme with many colour choices</zh_CN>
   <zh_TW>an updated/refreshed Faenza-ish icon theme with many colour choices</zh_TW>
</description>

<installable>
all
</installable>

<screenshot></screenshot>

<preinstall>

</preinstall>

<install_package_names>
obsidian-icon-theme
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
obsidian-icon-theme
</uninstall_package_names>
</app>
