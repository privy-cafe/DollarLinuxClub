<?xml version="1.0"?>
<app>

<category>
Office
</category>

<name>
Okular
</name>

<description>
   <am>a universal document viewer -WARNING- pulls in elements of KDE</am>
   <ar>a universal document viewer -WARNING- pulls in elements of KDE</ar>
   <bg>a universal document viewer -WARNING- pulls in elements of KDE</bg>
   <ca>visor de documents universal: COMPTE! descarrega elements de KDE</ca>
   <cs>a universal document viewer -WARNING- pulls in elements of KDE</cs>
   <da>en universel dokumentfremviser -ADVARSEL- trækker elementer fra KDE</da>
   <de>Ein universeller Dokumentbetrachter -WARNUNG- zieht Elemente von KDE ein</de>
   <el>ένα γενικό πρόγραμμα προβολής εγγράφων-ΠΡΟΕΙΔΟΠΟΙΗΣΗ- τραβάει στοιχεία του KDE</el>
   <en>a universal document viewer -WARNING- pulls in elements of KDE</en>
   <es>Visualizador universal de documentos -ADVERTENCIA- instala elementos de KDE</es>
   <et>a universal document viewer -WARNING- pulls in elements of KDE</et>
   <eu>a universal document viewer -WARNING- pulls in elements of KDE</eu>
   <fa>a universal document viewer -WARNING- pulls in elements of KDE</fa>
   <fi>a universal document viewer -WARNING- pulls in elements of KDE</fi>
   <fr>Visionneuse universelle de documments -ATTENTION- nécessite et installe des dépendances KDE</fr>
   <he_IL>a universal document viewer -WARNING- pulls in elements of KDE</he_IL>
   <hi>a universal document viewer -WARNING- pulls in elements of KDE</hi>
   <hr>a universal document viewer -WARNING- pulls in elements of KDE</hr>
   <hu>a universal document viewer -WARNING- pulls in elements of KDE</hu>
   <id>a universal document viewer -WARNING- pulls in elements of KDE</id>
   <is>a universal document viewer -WARNING- pulls in elements of KDE</is>
   <it>un visualizzatore universale di documenti -ATTENZIONE- richiama elementi di KDE</it>
   <ja_JP>a universal document viewer -WARNING- pulls in elements of KDE</ja_JP>
   <ja>a universal document viewer -WARNING- pulls in elements of KDE</ja>
   <kk>a universal document viewer -WARNING- pulls in elements of KDE</kk>
   <ko>a universal document viewer -WARNING- pulls in elements of KDE</ko>
   <lt>a universal document viewer -WARNING- pulls in elements of KDE</lt>
   <mk>a universal document viewer -WARNING- pulls in elements of KDE</mk>
   <mr>a universal document viewer -WARNING- pulls in elements of KDE</mr>
   <nb>a universal document viewer -WARNING- pulls in elements of KDE</nb>
   <nl>een universele document lezer -WAARSCHUWING- installeert elementen van KDE</nl>
   <pl>uniwersalna przeglądarka dokumentów - OSTRZEŻENIE - zawiera elementy KDE</pl>
   <pt_BR>Visualizador de documentos universal -AVISO- instala elementos do Ambiente de Trabalho KDE</pt_BR>
   <pt>Visualizador de documentos universal -AVISO- instala elementos do Ambiente de Trabalho KDE</pt>
   <ro>a universal document viewer -WARNING- pulls in elements of KDE</ro>
   <ru>Универсальный просмотрщик документов -ВНИМАНИЕ- тянет с собой элементы KDE</ru>
   <sk>a universal document viewer -WARNING- pulls in elements of KDE</sk>
   <sl>Univerzalni pregledovalnik dokumentov - POZOR - uporablja dele KDE okolja</sl>
   <sq>a universal document viewer -WARNING- pulls in elements of KDE</sq>
   <sr>a universal document viewer -WARNING- pulls in elements of KDE</sr>
   <sv>en universiell dokumentläsare -Varning- drar in delar av KDE</sv>
   <tr>a universal document viewer -WARNING- pulls in elements of KDE</tr>
   <uk>універсальний переглядач документів -ПОПЕРЕДЖЕННЯ- потребує елементи KDE</uk>
   <zh_CN>a universal document viewer -WARNING- pulls in elements of KDE</zh_CN>
   <zh_TW>a universal document viewer -WARNING- pulls in elements of KDE</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/009/644/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
okular
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
okular
</uninstall_package_names>
</app>
