<?xml version="1.0"?>
<app>

<category>
Newsreader
</category>

<name>
Pan
</name>

<description>
   <am>a gnome Usenet newsreader</am>
   <ar>a gnome Usenet newsreader</ar>
   <bg>a gnome Usenet newsreader</bg>
   <ca>lector de notícies Usenet</ca>
   <cs>a gnome Usenet newsreader</cs>
   <da>en gnome Usenet-nyhedslæser</da>
   <de>Ein Gnome Usenet Newsreader</de>
   <el>Usenet newsreader</el>
   <en>a gnome Usenet newsreader</en>
   <es>Lector de noticias Usenet de gnome</es>
   <et>a gnome Usenet newsreader</et>
   <eu>a gnome Usenet newsreader</eu>
   <fa>a gnome Usenet newsreader</fa>
   <fi>a gnome Usenet newsreader</fi>
   <fr>Un lecteur de nouvelles Usenet pour Gnome</fr>
   <he_IL>a gnome Usenet newsreader</he_IL>
   <hi>a gnome Usenet newsreader</hi>
   <hr>a gnome Usenet newsreader</hr>
   <hu>a gnome Usenet newsreader</hu>
   <id>a gnome Usenet newsreader</id>
   <is>a gnome Usenet newsreader</is>
   <it>lettore di news dalla rete Usenet basato su GTK2</it>
   <ja_JP>a gnome Usenet newsreader</ja_JP>
   <ja>a gnome Usenet newsreader</ja>
   <kk>a gnome Usenet newsreader</kk>
   <ko>a gnome Usenet newsreader</ko>
   <lt>a gnome Usenet newsreader</lt>
   <mk>a gnome Usenet newsreader</mk>
   <mr>a gnome Usenet newsreader</mr>
   <nb>a gnome Usenet newsreader</nb>
   <nl>a gnome Usenet nieuwslezer</nl>
   <pl>gnomowy czytnik grup dyskusyjnych Usenet</pl>
   <pt_BR>Agregador de notícias Usenet para gnome</pt_BR>
   <pt>Agregador de notícias Usenet para gnome</pt>
   <ro>a gnome Usenet newsreader</ro>
   <ru>Новостной клиент Usenet для окружения Gnome</ru>
   <sk>a gnome Usenet newsreader</sk>
   <sl>Bralnik novic za Usenet za Gnome okolje</sl>
   <sq>a gnome Usenet newsreader</sq>
   <sr>a gnome Usenet newsreader</sr>
   <sv>en gnome Usenet nyhetsläsare</sv>
   <tr>a gnome Usenet newsreader</tr>
   <uk>a gnome Usenet newsreader</uk>
   <zh_CN>a gnome Usenet newsreader</zh_CN>
   <zh_TW>a gnome Usenet newsreader</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/000/586/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
pan
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
pan
</uninstall_package_names>
</app>
