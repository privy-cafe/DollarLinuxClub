<?xml version="1.0"?>
<app>

<category>
Docks
</category>

<name>
Plank
</name>

<description>
   <am>Simple but good looking dock</am>
   <ar>Simple but good looking dock</ar>
   <bg>Simple but good looking dock</bg>
   <ca>Dock senzill però amb bon aspecte</ca>
   <cs>Simple but good looking dock</cs>
   <da>Simpel med flot dok</da>
   <de>Einfaches, aber gut aussehendes Dock</de>
   <el>Απλό αλλά όμορφο dock</el>
   <en>Simple but good looking dock</en>
   <es>dock simple y atractivo</es>
   <et>Simple but good looking dock</et>
   <eu>Simple but good looking dock</eu>
   <fa>Simple but good looking dock</fa>
   <fi>Simple but good looking dock</fi>
   <fr>Un dock sobre et agréable</fr>
   <he_IL>Simple but good looking dock</he_IL>
   <hi>Simple but good looking dock</hi>
   <hr>Simple but good looking dock</hr>
   <hu>Simple but good looking dock</hu>
   <id>Simple but good looking dock</id>
   <is>Simple but good looking dock</is>
   <it>barra dock semplice ma bella</it>
   <ja_JP>Simple but good looking dock</ja_JP>
   <ja>Simple but good looking dock</ja>
   <kk>Simple but good looking dock</kk>
   <ko>Simple but good looking dock</ko>
   <lt>Simple but good looking dock</lt>
   <mk>Simple but good looking dock</mk>
   <mr>Simple but good looking dock</mr>
   <nb>Simple but good looking dock</nb>
   <nl>Eenvoudig maar goed uitziende dock</nl>
   <pl>prosty, ale dobrze wyglądający panel dokujący</pl>
   <pt_BR>Doca simples mas elegante</pt_BR>
   <pt>Doca simples mas elegante</pt>
   <ro>Simple but good looking dock</ro>
   <ru>Простой но стильно выглядящий док</ru>
   <sk>Simple but good looking dock</sk>
   <sl>Enostaven a lep dock</sl>
   <sq>Simple but good looking dock</sq>
   <sr>Simple but good looking dock</sr>
   <sv>Enkel men snygg docka</sv>
   <tr>Simple but good looking dock</tr>
   <uk>простий, але гарний док</uk>
   <zh_CN>Simple but good looking dock</zh_CN>
   <zh_TW>Simple but good looking dock</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/015/110/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
plank
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
plank
</uninstall_package_names>
</app>
