<?xml version="1.0"?>
<app>

<category>
Children
</category>

<name>
Primary
</name>

<description>
   <am>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</am>
   <ar>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</ar>
   <bg>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</bg>
   <ca>Primària: inclou celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, i marble</ca>
   <cs>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</cs>
   <da>Grundskole. Inkluderer: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype og marble</da>
   <de>Grundschule: Enthält Celestia-Gnome, Gcompris, Laby, Ri-Li, Stellarium, Tuxmath, Tuxpaint, Tuxtype und Marmor.</de>
   <el>Πρωταρχικός. Περιλαμβάνει: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype και marble</el>
   <en>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</en>
   <es>Primario. Incluye: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, y marble</es>
   <et>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</et>
   <eu>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</eu>
   <fa>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</fa>
   <fi>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</fi>
   <fr>Primaire. Inclus: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, et marble</fr>
   <he_IL>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</he_IL>
   <hi>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</hi>
   <hr>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</hr>
   <hu>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</hu>
   <id>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</id>
   <is>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</is>
   <it>Medie. Include: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, e marble</it>
   <ja_JP>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</ja_JP>
   <ja>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</ja>
   <kk>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</kk>
   <ko>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</ko>
   <lt>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</lt>
   <mk>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</mk>
   <mr>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</mr>
   <nb>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</nb>
   <nl>Basis. Inclusief: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, en marble</nl>
   <pl>Szkoła podstawowa. Zawiera: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype i marble</pl>
   <pt_BR>Ensino fundamental (1º ao 6º ano). Inclui: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, e marble</pt_BR>
   <pt>Ensino básico, 1º e 2º ciclos. Inclui: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, e marble</pt>
   <ro>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</ro>
   <ru>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</ru>
   <sk>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</sk>
   <sl>Osnovna šola. Vsebuje: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype in marble</sl>
   <sq>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</sq>
   <sr>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</sr>
   <sv>Primary. Inkluderar: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, och marble</sv>
   <tr>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</tr>
   <uk>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</uk>
   <zh_CN>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</zh_CN>
   <zh_TW>Primary. Includes: celestia-gnome, gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
gcompris-qt
laby
ri-li
stellarium
tuxmath
tuxpaint
tuxtype
marble-qt
marble-plugins
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
gcompris-qt
laby
ri-li
stellarium
tuxmath
tuxpaint
tuxtype
marble-qt
marble-plugins
</uninstall_package_names>
</app>
