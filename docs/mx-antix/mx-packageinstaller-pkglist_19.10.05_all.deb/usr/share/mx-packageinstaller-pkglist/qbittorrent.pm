<?xml version="1.0"?>
<app>

<category>
Torrent
</category>

<name>
qBittorrent
</name>

<description>
   <am>a QT4 feature rich but lightweight client that is very similar to uTorrent</am>
   <ar>a QT4 feature rich but lightweight client that is very similar to uTorrent</ar>
   <bg>a QT4 feature rich but lightweight client that is very similar to uTorrent</bg>
   <ca>Un client potent però lleuger en QT4 molt semblant a uTorrent</ca>
   <cs>a QT4 feature rich but lightweight client that is very similar to uTorrent</cs>
   <da>En QT4 letvægts klient med mange funktionaliteter som minder meget om uTorrent</da>
   <de>Ein Qt4-Client mit vielen Funktionen, der dem µTorrent sehr ähnlich ist.</de>
   <el>ένα QT4 χαρακτηριστικό πλούσιο αλλά ελαφρύ πελάτη που είναι πολύ παρόμοιο με το uTorrent</el>
   <en>a QT4 feature rich but lightweight client that is very similar to uTorrent</en>
   <es>Cliente completo y liviano muy similar a uTorrent que utiliza QT4</es>
   <et>a QT4 feature rich but lightweight client that is very similar to uTorrent</et>
   <eu>a QT4 feature rich but lightweight client that is very similar to uTorrent</eu>
   <fa>a QT4 feature rich but lightweight client that is very similar to uTorrent</fa>
   <fi>a QT4 feature rich but lightweight client that is very similar to uTorrent</fi>
   <fr>Un client léger et complet basé sur QT4 et très similaire à uTorrent</fr>
   <he_IL>a QT4 feature rich but lightweight client that is very similar to uTorrent</he_IL>
   <hi>a QT4 feature rich but lightweight client that is very similar to uTorrent</hi>
   <hr>a QT4 feature rich but lightweight client that is very similar to uTorrent</hr>
   <hu>a QT4 feature rich but lightweight client that is very similar to uTorrent</hu>
   <id>a QT4 feature rich but lightweight client that is very similar to uTorrent</id>
   <is>a QT4 feature rich but lightweight client that is very similar to uTorrent</is>
   <it>client molto simile a uTorrent, ricco di funzionalità ma leggero, con interfaccia in QT4</it>
   <ja_JP>a QT4 feature rich but lightweight client that is very similar to uTorrent</ja_JP>
   <ja>a QT4 feature rich but lightweight client that is very similar to uTorrent</ja>
   <kk>a QT4 feature rich but lightweight client that is very similar to uTorrent</kk>
   <ko>a QT4 feature rich but lightweight client that is very similar to uTorrent</ko>
   <lt>a QT4 feature rich but lightweight client that is very similar to uTorrent</lt>
   <mk>a QT4 feature rich but lightweight client that is very similar to uTorrent</mk>
   <mr>a QT4 feature rich but lightweight client that is very similar to uTorrent</mr>
   <nb>a QT4 feature rich but lightweight client that is very similar to uTorrent</nb>
   <nl>een QT4 veelzijdig maar lichtgewicht programma die veel gelijkenis vertoont met uTorrent</nl>
   <pl>lekki i funkcjonalny klient oparty o QT4, bardzo podobny do uTorrent</pl>
   <pt_BR>Cliente de torrent para a tecnologia QT4, pleno de funcionalidades mas ligeiro, muito semelhante ao uTorrent</pt_BR>
   <pt>Cliente de torrent para a tecnologia QT4, pleno de funcionalidades mas ligeiro, muito semelhante ao uTorrent</pt>
   <ro>a QT4 feature rich but lightweight client that is very similar to uTorrent</ro>
   <ru>Мощный и легкий Bittorrent клиент на QT-4 похожий на uTorrent</ru>
   <sk>a QT4 feature rich but lightweight client that is very similar to uTorrent</sk>
   <sl>QT4 torren odjemalec, ki je zelo podoben uTorrentu</sl>
   <sq>a QT4 feature rich but lightweight client that is very similar to uTorrent</sq>
   <sr>a QT4 feature rich but lightweight client that is very similar to uTorrent</sr>
   <sv>en Qt4 lättvikts klient rik på möjligheter som är mycket lik uTorrent</sv>
   <tr>a QT4 feature rich but lightweight client that is very similar to uTorrent</tr>
   <uk>a QT4 feature rich but lightweight client that is very similar to uTorrent</uk>
   <zh_CN>a QT4 feature rich but lightweight client that is very similar to uTorrent</zh_CN>
   <zh_TW>a QT4 feature rich but lightweight client that is very similar to uTorrent</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/014/486/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
qbittorrent
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
qbittorrent
</uninstall_package_names>
</app>
