<?xml version="1.0"?>
<app>

<category>
Email
</category>

<name>
Thunderbird
</name>

<description>
   <am>Latest Thunderbird email client from MX Community</am>
   <ar>Latest Thunderbird email client from MX Community</ar>
   <bg>Latest Thunderbird email client from MX Community</bg>
   <ca>Darrer client de correu Thunderbird de la Comunitat MX</ca>
   <cs>Latest Thunderbird email client from MX Community</cs>
   <da>Seneste Thunderbird e-mailklient fra MX-fællesskabet</da>
   <de>Neuester Thunderbird E-Mail-Client von MX Community</de>
   <el>Τελευταίο πρόγραμμα-πελάτη ηλεκτρονικού ταχυδρομείου Thunderbird από την κοινότητα MX</el>
   <en>Latest Thunderbird email client from MX Community</en>
   <es>El último Thunderbird (cliente de correo) de la comunidad MX</es>
   <et>Latest Thunderbird email client from MX Community</et>
   <eu>Latest Thunderbird email client from MX Community</eu>
   <fa>Latest Thunderbird email client from MX Community</fa>
   <fi>Viimeisin MX-yhteisön Thunderbird sähköpostiohjelma</fi>
   <fr>La dernière version du client mail Thunderbird par la Communauté MX</fr>
   <he_IL>Latest Thunderbird email client from MX Community</he_IL>
   <hi>Latest Thunderbird email client from MX Community</hi>
   <hr>Latest Thunderbird email client from MX Community</hr>
   <hu>Latest Thunderbird email client from MX Community</hu>
   <id>Latest Thunderbird email client from MX Community</id>
   <is>Latest Thunderbird email client from MX Community</is>
   <it>l'ultima versione di client email Thunderbird dalla MX Community</it>
   <ja_JP>Latest Thunderbird email client from MX Community</ja_JP>
   <ja>Latest Thunderbird email client from MX Community</ja>
   <kk>Latest Thunderbird email client from MX Community</kk>
   <ko>Latest Thunderbird email client from MX Community</ko>
   <lt>Latest Thunderbird email client from MX Community</lt>
   <mk>Latest Thunderbird email client from MX Community</mk>
   <mr>Latest Thunderbird email client from MX Community</mr>
   <nb>Latest Thunderbird email client from MX Community</nb>
   <nl>Meest recente Thunderbird email programma vanuit MX Community</nl>
   <pl>najnowszy klient poczty e-mail Thunderbird od społeczności MX</pl>
   <pt_BR>Thunderbird (cliente de e-mail) mais recente da comunidade MX</pt_BR>
   <pt>Thunderbird (cliente de correio-electrónico) mais recente da comunidade MX</pt>
   <ro>Latest Thunderbird email client from MX Community</ro>
   <ru>Почтовый клиент Thunderbird последней версии из MX Community</ru>
   <sk>Latest Thunderbird email client from MX Community</sk>
   <sl>Zadnja različica poštnega odjemalca Thunderbird iz MX skupnosti</sl>
   <sq>Latest Thunderbird email client from MX Community</sq>
   <sr>Latest Thunderbird email client from MX Community</sr>
   <sv>Senaste Thunderbird mejlklient från MX Community</sv>
   <tr>Latest Thunderbird email client from MX Community</tr>
   <uk>Latest Thunderbird email client from MX Community</uk>
   <zh_CN>Latest Thunderbird email client from MX Community</zh_CN>
   <zh_TW>Latest Thunderbird email client from MX Community</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/009/137/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird
</uninstall_package_names>
</app>
