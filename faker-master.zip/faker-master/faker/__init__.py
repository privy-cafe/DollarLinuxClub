from faker.generator import Generator  # noqa F401
from faker.factory import Factory  # noqa F401
from faker.proxy import Faker  # noqa F401

VERSION = '3.0.0'
