# coding=utf-8
from ..en_PH import Provider as EnPhAutomotiveProvider


class Provider(EnPhAutomotiveProvider):
    """No difference from Automotive Provider for en_PH locale"""
    pass
