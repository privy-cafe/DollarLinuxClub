from .. import Provider as CurrencyProvider


class Provider(CurrencyProvider):
    pass
