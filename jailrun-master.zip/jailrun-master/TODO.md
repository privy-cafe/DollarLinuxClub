TODO
====

* v0.1.2
    * Add option and functionality for auto-maximizing the app within xephyr window on launch.
* v0.1.3
    * Allow grouping and reuse of different xephyr (and window manager) instances by name, like a poor-man's Qubes
      e.g. "voip" = Zoom, Skype, Jitsi; "browser" = Firefox, Chromium, Filezilla; etc.
