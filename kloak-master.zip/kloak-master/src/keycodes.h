#ifndef KEYCODES_H_INCLUDED
#define KEYCODES_H_INCLUDED

int lookup_keycode(const char *);
const char* lookup_keyname(const int);

#endif // KEYCODES_H_INCLUDED
