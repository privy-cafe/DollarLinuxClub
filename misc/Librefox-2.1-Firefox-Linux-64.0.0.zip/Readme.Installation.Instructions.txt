IMPORTANT NOTICE: this is a temporary version, awaiting a correct build of the project, Librefox is distributed as a configuration files for Firefox. To apply Librefox configuration to Firefox extract the compressed file to Firefox's installation directory. Future Librefox version will be independant from Firefox and therefore solve this issue. 

INFO: in the current state of the project Librefox is a set of configuration files for Firefox (awaiting a correct build of the project), therefore if you already have a Firefox profile, that profile will be used and temporary files will be removed (cookies and current session), make sure to backup your current Firefox's profile before using Librefox.
Using Librefox simultaneously with Firefox is possilbe through a different profile you can follow this wiki (https://www.ghacks.net/2008/05/29/run-multiple-firefox-profiles-simultaneously/) to do so. Future Librefox version will be independant from Firefox and therefore solve this issue. 

Windows
- Download and install the last version of Firefox 
  Windows-x32-release: https://download-installer.cdn.mozilla.net/pub/firefox/releases/64.0/win32/en-US/Firefox%20Setup%2064.0.exe
  Windows-x64-release: https://download-installer.cdn.mozilla.net/pub/firefox/releases/64.0/win64/en-US/Firefox%20Setup%2064.0.exe
- Locate Firefox's installation directory (where the firefox.exe is located) `C:\Program Files\Mozilla Firefox\` or `C:\Program Files (x86)\Mozilla Firefox\` or `Tor-Install-Directory\Browser\`
- Copy the extracted Librefox files to the install directory

Linux
- Download and extract the last version of Firefox 
  Linux-x32-release: https://download-installer.cdn.mozilla.net/pub/firefox/releases/64.0/linux-i686/en-US/firefox-64.0.tar.bz2
  Linux-x64-release: https://download-installer.cdn.mozilla.net/pub/firefox/releases/64.0/linux-x86_64/en-US/firefox-64.0.tar.bz2
- Copy the extracted Librefox files to the newly downloaded `firefox` directory
- You can use directly Librefox by running 'firefox/firefox'
- You can as well create a shortcut to 'firefox/firefox' to open Librefox easily.

Mac
- Download and install the last version of Firefox 
  Mac-x64-release: https://download-installer.cdn.mozilla.net/pub/firefox/releases/64.0/mac/en-US/Firefox%2064.0.dmg
- Locate Firefox's installation directory (`Applications/Firefox.app/Contents/Resources/` or `Applications/Tor Browser.app/Contents/Resources/`)
- Copy the extracted files to the install directory 
