# hardened-vm-kernel

Hardened kernel configuration optimized for virtual machines. Only Virtualbox, KVM and Xen are supported.
